import React from 'react';
import Jobdetail from '../jobboard/jobdetail';

const JobDetailPage = () => {
  return (
    <div>
      <Jobdetail />
    </div>
  );
}

export default JobDetailPage;
