import React from 'react';
import Hrdetail from '../hrnews/hrdetail';

const HrDetailPage = () => {
  return (
    <div>
      <Hrdetail />
    </div>
  );
}

export default HrDetailPage;
